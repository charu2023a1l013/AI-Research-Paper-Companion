import arxiv
import requests
import xml.etree.ElementTree as ET
from datetime import datetime

def search_arxiv_papers(keyword, max_results=5):
    """
    Search for papers on arXiv based on a keyword
    """
    try:
        search = arxiv.Search(
            query=keyword,
            max_results=max_results,
            sort_by=arxiv.SortCriterion.SubmittedDate,
            sort_order=arxiv.SortOrder.Descending
        )
        
        papers = []
        for result in search.results():
            paper = {
                'title': result.title,
                'authors': [author.name for author in result.authors],
                'abstract': result.summary,
                'published': result.published.strftime("%Y-%m-%d"),
                'pdf_url': result.pdf_url,
                'entry_id': result.entry_id,
                'primary_category': result.primary_category
            }
            papers.append(paper)
        
        return papers
    except Exception as e:
        print(f"Error searching arXiv: {str(e)}")
        # Fallback to direct API call
        return search_arxiv_papers_direct(keyword, max_results)

def search_arxiv_papers_direct(keyword, max_results=5):
    """
    Search for papers on arXiv using direct API calls (fallback)
    """
    try:
        # Format the query URL properly
        base_url = "http://export.arxiv.org/api/query?"
        search_query = f"search_query=all:{keyword}"
        params = f"&sortBy=submittedDate&sortOrder=descending&start=0&max_results={max_results}"
        url = base_url + search_query + params
        
        response = requests.get(url)
        
        if response.status_code != 200:
            return []
        
        # Parse the XML response
        root = ET.fromstring(response.content)
        
        # Define namespace for XML parsing
        ns = {'atom': 'http://www.w3.org/2005/Atom'}
        
        papers = []
        for entry in root.findall('atom:entry', ns):
            title = entry.find('atom:title', ns).text.strip() if entry.find('atom:title', ns) is not None else "No title"
            
            authors = []
            for author in entry.findall('atom:author/atom:name', ns):
                authors.append(author.text)
                
            summary = entry.find('atom:summary', ns).text.strip() if entry.find('atom:summary', ns) is not None else "No abstract"
            
            published = entry.find('atom:published', ns).text
            if published:
                published_date = datetime.strptime(published, '%Y-%m-%dT%H:%M:%SZ')
                published_str = published_date.strftime("%Y-%m-%d")
            else:
                published_str = "Unknown date"
                
            paper_id = entry.find('atom:id', ns).text if entry.find('atom:id', ns) is not None else ""
            
            # Find PDF link
            pdf_url = ""
            for link in entry.findall('atom:link', ns):
                if link.get('title') == 'pdf':
                    pdf_url = link.get('href')
                    break
            
            papers.append({
                'title': title,
                'authors': authors,
                'abstract': summary,
                'published': published_str,
                'pdf_url': pdf_url,
                'entry_id': paper_id,
                'primary_category': entry.find('atom:primaryCategory', ns).get('term') if entry.find('atom:primaryCategory', ns) is not None else ""
            })
        
        return papers
    except Exception as e:
        print(f"Error in arXiv API: {str(e)}")
        return []

def get_paper_content(paper_id):
    """
    Get the content of a paper (for future expansion to full text)
    """
    try:
        search = arxiv.Search(id_list=[paper_id])
        paper = next(search.results())
        return paper.summary
    except Exception as e:
        print(f"Error getting paper content: {str(e)}")
        return "Content not available"
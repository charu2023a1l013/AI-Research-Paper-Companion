import openai
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Set your OpenAI API key
openai.api_key = os.getenv('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')

def summarize_text(text, max_tokens=150):
    """
    Summarize text using OpenAI's API
    """
    try:
        # Truncate text if it's too long (to avoid token limits)
        if len(text) > 3000:
            text = text[:3000] + "..."
            
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a research assistant. Summarize the following research paper abstract in a concise manner. Focus on the key contributions and findings."},
                {"role": "user", "content": f"Please summarize this research paper abstract:\n\n{text}"}
            ],
            max_tokens=max_tokens,
            temperature=0.3
        )
        return response.choices[0].message['content'].strip()
    except Exception as e:
        print(f"OpenAI API Error in summarization: {str(e)}")
        return f"Summary not available due to API error: {str(e)}"

def analyze_research_gaps(text):
    """
    Analyze research gaps using OpenAI's API
    """
    try:
        # Truncate text if it's too long (to avoid token limits)
        if len(text) > 3000:
            text = text[:3000] + "..."
            
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a research analyst. Identify potential research gaps, limitations, or future research directions based on the following text. Be specific and constructive."},
                {"role": "user", "content": f"Based on this research paper abstract, identify potential research gaps or suggest future research directions:\n\n{text}"}
            ],
            max_tokens=200,
            temperature=0.5
        )
        return response.choices[0].message['content'].strip()
    except Exception as e:
        print(f"OpenAI API Error in gap analysis: {str(e)}")
        return f"Research gap analysis not available due to API error: {str(e)}"
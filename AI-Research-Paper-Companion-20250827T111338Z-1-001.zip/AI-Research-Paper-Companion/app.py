from flask import Flask, render_template, request, jsonify
from utils.arxiv_api import search_arxiv_papers
from utils.openai_api import summarize_text, analyze_research_gaps
import os

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search', methods=['POST'])
def search_papers():
    keyword = request.form.get('keyword')
    max_results = int(request.form.get('max_results', 3))
    
    if not keyword:
        return jsonify({'error': 'Keyword is required'}), 400
    
    try:
        papers = search_arxiv_papers(keyword, max_results)
        
        if not papers:
            return jsonify({'error': 'No papers found or error connecting to arXiv. Try a different keyword.'}), 404
        
        # Process each paper with OpenAI API
        for paper in papers:
            paper['summary'] = summarize_text(paper['abstract'])
            paper['research_gaps'] = analyze_research_gaps(paper['abstract'])
        
        return jsonify({'papers': papers})
    except Exception as e:
        return jsonify({'error': f'Server error: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)